const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const box = 20;
let score = 0;
let level = 0;
let applesEaten = 0;
let pointMultiplier = 1;
let speed = 200;
let gameInterval;
let direction = "RIGHT";
let nextDirection = "RIGHT";
let gameOver = false;
let superApple = false;
let superAppleChance = 0.1;

const colors = ["lime", "gold", "deepskyblue", "magenta", "white", "lime", "gold", "deepskyblue", "magenta", "white"];
const tailColors = ["#bfff9f", "#ffe680", "#a0e8ff", "#ff99ff", "#cccccc", "#bfff9f", "#ffe680", "#a0e8ff", "#ff99ff", "#cccccc"];

let snake = [{ x: 9 * box, y: 9 * box }, { x: 8 * box, y: 9 * box }];

let food = {
  x: Math.floor(Math.random() * 19) * box,
  y: Math.floor(Math.random() * 19) * box
};

let particles = [];
let levelUpMessage = null;
let levelUpTimer = 0;

function spawnFood() {
  food = {
    x: Math.floor(Math.random() * 19) * box,
    y: Math.floor(Math.random() * 19) * box
  };
  superApple = Math.random() < superAppleChance;
}

document.addEventListener("keydown", event => {
  const key = event.key;
  if (key === "ArrowLeft" && direction !== "RIGHT") nextDirection = "LEFT";
  else if (key === "ArrowUp" && direction !== "DOWN") nextDirection = "UP";
  else if (key === "ArrowRight" && direction !== "LEFT") nextDirection = "RIGHT";
  else if (key === "ArrowDown" && direction !== "UP") nextDirection = "DOWN";
});

function drawCircle(x, y, radius, fillColor, glow = false) {
  ctx.beginPath();
  ctx.arc(x + box / 2, y + box / 2, radius, 0, Math.PI * 2);
  ctx.fillStyle = fillColor;
  ctx.shadowColor = glow ? fillColor : "transparent";
  ctx.shadowBlur = glow ? 15 : 0;
  ctx.fill();
  ctx.shadowBlur = 0;
}

function interpolate(a, b, t) {
  return a + (b - a) * t;
}

function createParticles(x, y, color) {
  for (let i = 0; i < 20; i++) {
    particles.push({
      x: x + box / 2,
      y: y + box / 2,
      radius: Math.random() * 3 + 2,
      color,
      dx: (Math.random() - 0.5) * 4,
      dy: (Math.random() - 0.5) * 4,
      life: 40
    });
  }
}

function drawParticles() {
  particles.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
    ctx.fillStyle = p.color;
    ctx.globalAlpha = Math.max(p.life / 40, 0);
    ctx.fill();
    ctx.globalAlpha = 1;
    p.x += p.dx;
    p.y += p.dy;
    p.life--;
  });
  particles = particles.filter(p => p.life > 0);
}

function showLevelUpMessage(x, y) {
  levelUpMessage = { x, y };
  levelUpTimer = 60; // 1 segundo a 60fps
}

let animationProgress = 1;
let lastTimestamp = 0;
let snakePrev = [...snake];

function animate(timestamp) {
  if (gameOver) return;

  if (!lastTimestamp) lastTimestamp = timestamp;
  let delta = timestamp - lastTimestamp;
  lastTimestamp = timestamp;

  animationProgress += delta / speed;
  if (animationProgress > 1) animationProgress = 1;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < snake.length; i++) {
    const prev = snakePrev[i] || snake[i];
    const curr = snake[i];
    const interpX = interpolate(prev.x, curr.x, animationProgress);
    const interpY = interpolate(prev.y, curr.y, animationProgress);
    const isHead = i === 0;
    const color = isHead ? colors[level] || "lime" : tailColors[level] || "lightgreen";
    const glow = level >= 5;
    drawCircle(interpX, interpY, box / 2 - 2, color, glow);
  }

  drawCircle(food.x, food.y, box / 2 - 2, superApple ? "yellow" : "red");

  drawParticles();

  if (levelUpMessage && levelUpTimer > 0) {
    ctx.font = "bold 12px monospace";
    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.fillText("Level Up!", levelUpMessage.x + box / 2, levelUpMessage.y - 5);
    levelUpTimer--;
    if (levelUpTimer <= 0) levelUpMessage = null;
  }

  requestAnimationFrame(animate);
}

function update() {
  if (gameOver) return;
  direction = nextDirection;
  snakePrev = [...snake];
  animationProgress = 0;

  let headX = snake[0].x;
  let headY = snake[0].y;

  if (direction === "LEFT") headX -= box;
  if (direction === "UP") headY -= box;
  if (direction === "RIGHT") headX += box;
  if (direction === "DOWN") headY += box;

  const newHead = { x: headX, y: headY };

  if (
    headX < 0 || headY < 0 ||
    headX >= canvas.width || headY >= canvas.height ||
    snake.some(segment => segment.x === newHead.x && segment.y === newHead.y)
  ) {
    endGame();
    return;
  }

  if (headX === food.x && headY === food.y) {
    const gainedPoints = superApple ? 5 : 1;
    applesEaten += 1;
    score += Math.floor(gainedPoints * pointMultiplier);

    if (applesEaten % 5 === 0 && level < 9) {
      level++;
      pointMultiplier += 0.25;
      speed = Math.max(50, speed - 15);
      superAppleChance += 0.05;
      clearInterval(gameInterval);
      gameInterval = setInterval(update, speed);
      snake = [snake[0], { x: snake[0].x - box, y: snake[0].y }];

      // Efeito visual de level up
      createParticles(newHead.x, newHead.y, colors[level] || "white");
      showLevelUpMessage(newHead.x, newHead.y);
    }

    spawnFood();
  } else {
    snake.pop();
  }

  snake.unshift(newHead);

  document.getElementById("scoreDisplay").innerText =
    "Pontuação: " + score + " | Nível: " + level;
}

function endGame() {
  gameOver = true;
  saveScore(score);
  setTimeout(() => {
    alert("Fim de jogo! Pontuação: " + score);
    window.location.href = "scoreboard.html";
  }, 200);
}

/*function saveScore(score) {
  const nickname = localStorage.getItem("nickname") || "Desconhecido";
  const scoreboard = JSON.parse(localStorage.getItem("scoreboard") || "[]");
  scoreboard.push({ nickname, score });
  scoreboard.sort((a, b) => b.score - a.score);
  localStorage.setItem("scoreboard", JSON.stringify(scoreboard.slice(0, 10)));
}*/

function saveScore(score) {
  const nickname = localStorage.getItem("nickname") || "Desconhecido";

  const payload = {
    datascore: new Date().toISOString(),
    nickname: nickname,
    game: "Snake",
    score: score.toFixed(2)
  };

  fetch("http://localhost:3000/api/scores", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  })
  .then(response => {
    if (!response.ok) throw new Error("Erro ao guardar score na API.");
    console.log("Score guardado com sucesso!");
  })
  .catch(error => {
    console.error("Erro ao guardar score na API:", error);
    // backup local se falhar
    const scoreboard = JSON.parse(localStorage.getItem("scoreboard") || "[]");
    scoreboard.push({ nickname, score });
    scoreboard.sort((a, b) => b.score - a.score);
    localStorage.setItem("scoreboard", JSON.stringify(scoreboard.slice(0, 10)));
  });
}

spawnFood();
gameInterval = setInterval(update, speed);
requestAnimationFrame(animate);
