const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const box = 20;
let score = 0;
let level = 0;
let applesEaten = 0;
let pointMultiplier = 1;
let speed = 200;
let gameInterval;
let direction = "RIGHT";
let gameOver = false;

const colors = ["lime", "yellow", "blue", "purple", "red", "white"];
let snake = [
  { x: 9 * box, y: 9 * box },
  { x: 8 * box, y: 9 * box }
];

let food = {
  x: Math.floor(Math.random() * 19) * box,
  y: Math.floor(Math.random() * 19) * box,
};

document.addEventListener("keydown", event => {
  const key = event.key;
  if (key === "ArrowLeft" && direction !== "RIGHT") direction = "LEFT";
  else if (key === "ArrowUp" && direction !== "DOWN") direction = "UP";
  else if (key === "ArrowRight" && direction !== "LEFT") direction = "RIGHT";
  else if (key === "ArrowDown" && direction !== "UP") direction = "DOWN";
});

function draw() {
  if (gameOver) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < snake.length; i++) {
    ctx.fillStyle = i === 0 ? colors[level] : "green";
    ctx.fillRect(snake[i].x, snake[i].y, box, box);
  }

  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, box, box);

  let headX = snake[0].x;
  let headY = snake[0].y;

  if (direction === "LEFT") headX -= box;
  if (direction === "UP") headY -= box;
  if (direction === "RIGHT") headX += box;
  if (direction === "DOWN") headY += box;

  const newHead = { x: headX, y: headY };

  // colisão
  if (
    headX < 0 || headY < 0 ||
    headX >= canvas.width || headY >= canvas.height ||
    snake.some(segment => segment.x === newHead.x && segment.y === newHead.y)
  ) {
    endGame();
    return;
  }

  // comida
  if (headX === food.x && headY === food.y) {
    applesEaten++;
    score += Math.floor(1 * pointMultiplier);
    if (applesEaten % 10 === 0 && level < 5) {
      level++;
      pointMultiplier += 0.25;
      speed = Math.max(50, speed - 25);
      clearInterval(gameInterval);
      gameInterval = setInterval(draw, speed);
      // reset corpo
      snake = [snake[0], { x: snake[0].x - box, y: snake[0].y }];
    }
    food = {
      x: Math.floor(Math.random() * 19) * box,
      y: Math.floor(Math.random() * 19) * box,
    };
  } else {
    snake.pop();
  }

  snake.unshift(newHead);
  document.getElementById("scoreDisplay").innerText =
    "Pontuação: " + score + " | Nível: " + level;
}

function endGame() {
  gameOver = true;
  saveScore(score);
  setTimeout(() => {
    alert("Fim de jogo! Pontuação: " + score);
    window.location.href = "scoreboard.html";
  }, 200);
}

function saveScore(score) {
  const nickname = localStorage.getItem("nickname") || "Desconhecido";
  const scoreboard = JSON.parse(localStorage.getItem("scoreboard") || "[]");
  scoreboard.push({ nickname, score });
  scoreboard.sort((a, b) => b.score - a.score);
  localStorage.setItem("scoreboard", JSON.stringify(scoreboard.slice(0, 10)));
}

gameInterval = setInterval(draw, speed);