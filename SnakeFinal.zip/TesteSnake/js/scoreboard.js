/*const table = document.getElementById("scoreTable");
const scores = JSON.parse(localStorage.getItem("scoreboard") || "[]");

table.innerHTML = "<tr><th>#</th><th>Nickname</th><th>Pontuação</th></tr>";
scores.slice(0, 10).forEach((entry, index) => {
  const row = table.insertRow();
  row.innerHTML = `<td>${index + 1}</td><td>${entry.nickname}</td><td>${entry.score}</td>`;
});*/
//alert('comecei')
const table = document.getElementById("scoreTable");

fetch("http://localhost:3000/api/scores")
  .then(response => response.json())
  .then(data => {
    // Filtrar apenas os do jogo Snake (caso uses múltiplos jogos)
    const snakeScores = data
      .filter(entry => entry.game === "Snake")
      .sort((a, b) => parseFloat(b.score) - parseFloat(a.score))
      .slice(0, 10);

    table.innerHTML = "<tr><th>#</th><th>Nicknameaa</th><th>Pontuação</th></tr>";

    snakeScores.forEach((entry, index) => {
      const row = table.insertRow();
      row.innerHTML = `
        <td>${index + 1}</td>
        <td>${entry.nickname}</td>
        <td>${entry.score}</td>
      `;
    });
  })
  .catch(error => {
    console.error("Erro ao carregar scores:", error);
    table.innerHTML = "<tr><td colspan='3'>Erro ao carregar os dados.</td></tr>";
  });
//alert('terminei')