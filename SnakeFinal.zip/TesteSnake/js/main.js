function startGame() {
  const nickname = document.getElementById("nickname").value.trim();
  if (!nickname) {
    alert("Por favor, insere o teu nickname.");
    return;
  }
  localStorage.setItem("nickname", nickname);
  window.location.href = "game.html";
}
console.log(new Date().toISOString())