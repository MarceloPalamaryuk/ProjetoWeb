// routes/categorias.js
const express = require('express');
const router = express.Router();
const dbs = require('../db');

// GET todos os produtos
router.get('/', (req, res) => {
  dbs.query('SELECT * FROM categorias', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// GET categorias por ID
router.get('/:id', (req, res) => {
  dbs.query('SELECT * FROM categorias WHERE id = ?', [req.params.id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
});

// POST criar categorias
router.post('/', (req, res) => {
  const { nome } = req.body;
  dbs.query('INSERT INTO categorias (nome) VALUES (?)', [nome], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ id: result.insertId, nome });
  });
});

// PUT atualizar categorias
router.put('/:id', (req, res) => {
  const { nome } = req.body;
  dbs.query('UPDATE categorias SET nome = ? WHERE id = ?', [nome, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ id: req.params.id, nome });
  });
});

// DELETE produto
router.delete('/:id', (req, res) => {
  dbs.query('DELETE FROM categorias WHERE id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ status: 'Categoria removido' });
  });
});

module.exports = router;