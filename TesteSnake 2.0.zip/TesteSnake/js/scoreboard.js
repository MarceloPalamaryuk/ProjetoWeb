const table = document.getElementById("scoreTable");
const scores = JSON.parse(localStorage.getItem("scoreboard") || "[]");

table.innerHTML = "<tr><th>#</th><th>Nickname</th><th>Pontuação</th></tr>";
scores.slice(0, 10).forEach((entry, index) => {
  const row = table.insertRow();
  row.innerHTML = `<td>${index + 1}</td><td>${entry.nickname}</td><td>${entry.score}</td>`;
});